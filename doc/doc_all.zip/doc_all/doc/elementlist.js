
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","AcColor"],["c","AcImage"],["c","AcImageGIF"],["c","AcImageJPG"],["c","AcImagePNG"],["c","Exception"],["c","FileAlreadyExistsException"],["c","FileNotFoundException"],["c","FileNotSaveException"],["c","GDnotInstalledException"],["c","IllegalArgumentException"],["c","InvalidChannelException"],["c","InvalidFileException"],["c","Point"],["c","Rectangle"],["c","Size"],["c","UnsupportedFormatException"]];
